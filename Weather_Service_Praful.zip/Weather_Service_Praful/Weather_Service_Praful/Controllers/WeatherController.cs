﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Weather_Service.Models;
using Weather_Services;


namespace Weather_Service_Praful.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WeatherController : ControllerBase
    {
        private readonly WeatherService _weatherService;

        public WeatherController(WeatherService weatherService)
        {
            _weatherService = weatherService;
        }

        [HttpPost("getWeather")]
        public async Task<IActionResult> GetWeather([FromBody] List<int> cityIds)
        {
            var weatherDataList = new List<WeatherData>();

            foreach (var cityId in cityIds)
            {
                var weatherData = await _weatherService.GetWeatherByCityIdAsync(cityId);
                weatherDataList.Add(weatherData);
            }

            return Ok(weatherDataList);
        }

    }
}
