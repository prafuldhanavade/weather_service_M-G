using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Weather_Repositories;
using Weather_Services;



var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddSingleton<WeatherService>();
builder.Services.AddSingleton<CityRepository>();
builder.Services.AddSingleton<OutputRepository>();
builder.Services.AddHttpClient();
ConfigureSwagger(builder.Services);
var app = builder.Build();

app.UseRouting();
app.UseEndpoints(endpoints => endpoints.MapControllers());

app.Run();
static void ConfigureSwagger(IServiceCollection services)
{
    services.AddSwaggerGen(s =>
    {
        s.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo()
        {
            Version = "v1",
            Title = "Weather Service By Praful",
            Description = " This is Weather Service"
        });
        s.ResolveConflictingActions(a => a.First());
    });
}