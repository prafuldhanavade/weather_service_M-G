﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Weather_Service.Models;

namespace Weather_Services
{
    public class WeatherService
    {
        private const string ApiKey = "aa69195559bd4f88d79f9aadeb77a8f6";
        private const string BaseUrl = "https://api.openweathermap.org/data/2.5/weather";

        private readonly HttpClient _httpClient;

        public WeatherService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<WeatherData> GetWeatherByCityIdAsync(int cityId)
        {
            string url = $"{BaseUrl}?id={cityId}&appid={ApiKey}";
            HttpResponseMessage response = await _httpClient.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Failed to retrieve weather data for city ID: {cityId}");
            }

            string content = await response.Content.ReadAsStringAsync();
            var json = JsonSerializer.Deserialize<JsonElement>(content);

            return new WeatherData
            {
                CityName = json.GetProperty("name").GetString(),
                Description = json.GetProperty("weather")[0].GetProperty("description").GetString(),
                Temperature = json.GetProperty("main").GetProperty("temp").GetDouble(),
                Humidity = json.GetProperty("main").GetProperty("humidity").GetDouble(),
                WindSpeed = json.GetProperty("wind").GetProperty("speed").GetDouble()
            };
        }

    }
}
