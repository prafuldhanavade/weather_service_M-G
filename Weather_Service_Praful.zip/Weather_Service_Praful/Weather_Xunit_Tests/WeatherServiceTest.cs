﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weather_Services;

namespace Weather_Xunit_Tests
{
    public class WeatherServiceTest
    {
        [Fact]
        public async Task GetWeatherByCityIdAsync_ReturnsWeatherData()
        {
            // Arrange
            var httpClient = new HttpClient();
            var service = new WeatherService(httpClient);

            // Act
            var result = await service.GetWeatherByCityIdAsync(1273294); // Delhi

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Delhi", result.CityName);
        }

    }
}
