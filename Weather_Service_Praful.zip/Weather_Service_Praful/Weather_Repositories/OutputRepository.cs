﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Weather_Service.Models;

namespace Weather_Repositories
{
    public class OutputRepository
    {
        private const string OutputFolderPath = "./Data/Output/";

        public void SaveWeatherData(WeatherData data)
        {
            string fileName = $"{OutputFolderPath}{data.CityName}_{System.DateTime.Now:yyyy-MM-dd}.json";

            if (!Directory.Exists(OutputFolderPath))
            {
                Directory.CreateDirectory(OutputFolderPath);
            }

            string json = JsonSerializer.Serialize(data);
            File.WriteAllText(fileName, json);
        }
    }
}
