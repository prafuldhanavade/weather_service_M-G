﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weather_Repositories
{
    public class CityRepository
    {
        private const string InputFilePath = "./Data/CityList.txt";

        public List<int> GetCityIds()
        {
            var cityIds = new List<int>();

            foreach (var line in File.ReadAllLines(InputFilePath))
            {
                if (int.TryParse(line.Split('=')[0], out int cityId))
                {
                    cityIds.Add(cityId);
                }
            }

            return cityIds;
        }
    }
}
